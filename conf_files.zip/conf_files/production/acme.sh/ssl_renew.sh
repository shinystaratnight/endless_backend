/home/ubuntu/.acme.sh/acme.sh --force --issue -d piipai.com -d *.piipai.com --dns dns_zone
/home/ubuntu/.acme.sh/acme.sh --force --installcert -d piipai.com --key-file /etc/letsencrypt/live/piipai.com/privkey.pem --fullchain-file /etc/letsencrypt/live/piipai.com/fullchain.pem --capath /etc/letsencrypt/live/piipai.com/chain.pem

